﻿namespace FCG.TechChallenge.Jogos.Domain.ValueObjects
{
    public class Money
    {
    }
}
