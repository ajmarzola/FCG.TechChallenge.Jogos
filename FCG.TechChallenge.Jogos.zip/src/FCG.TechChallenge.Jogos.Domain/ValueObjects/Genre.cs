﻿namespace FCG.TechChallenge.Jogos.Domain.ValueObjects
{
    public class Genre
    {
    }
}
