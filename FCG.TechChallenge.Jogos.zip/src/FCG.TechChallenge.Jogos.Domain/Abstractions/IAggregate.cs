﻿namespace FCG.TechChallenge.Jogos.Domain.Abstractions
{
    public interface IAggregate
    {
    }
}
