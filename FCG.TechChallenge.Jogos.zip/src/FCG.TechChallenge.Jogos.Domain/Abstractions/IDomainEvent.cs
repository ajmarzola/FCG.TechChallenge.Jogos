﻿namespace FCG.TechChallenge.Jogos.Domain.Abstractions
{
    public interface IDomainEvent
    {
    }
}
