﻿namespace FCG.TechChallenge.Jogos.Domain.Events
{
    public class PaymentSucceeded
    {
    }
}
