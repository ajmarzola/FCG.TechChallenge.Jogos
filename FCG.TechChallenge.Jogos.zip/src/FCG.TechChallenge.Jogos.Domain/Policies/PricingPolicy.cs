﻿namespace FCG.TechChallenge.Jogos.Domain.Policies
{
    public class PricingPolicy
    {
    }
}
