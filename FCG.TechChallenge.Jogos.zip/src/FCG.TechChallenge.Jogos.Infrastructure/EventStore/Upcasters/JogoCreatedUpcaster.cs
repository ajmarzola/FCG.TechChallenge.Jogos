﻿namespace FCG.TechChallenge.Jogos.Infrastructure.EventStore.Upcasters
{
    public class JogoCreatedUpcaster
    {
    }
}
