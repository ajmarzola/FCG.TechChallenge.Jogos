﻿namespace FCG.TechChallenge.Jogos.Infrastructure.EventStore.Serialization
{
    public class SystemTextJsonEventSerializer
    {
    }
}
