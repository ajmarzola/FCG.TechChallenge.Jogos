﻿namespace FCG.TechChallenge.Jogos.Infrastructure.EventStore.Sql
{
    public class SqlEventStore
    {
    }
}
