﻿namespace FCG.TechChallenge.Jogos.Infrastructure.Messaging.ServiceBus
{
    public class ServiceBusPublisher
    {
    }
}
