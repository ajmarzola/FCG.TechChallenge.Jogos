﻿namespace FCG.TechChallenge.Jogos.Infrastructure.Outbox
{
    public class SqlOutbox
    {
    }
}
