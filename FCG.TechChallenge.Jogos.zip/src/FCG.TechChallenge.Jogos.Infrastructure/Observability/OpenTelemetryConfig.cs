﻿namespace FCG.TechChallenge.Jogos.Infrastructure.Observability
{
    public class OpenTelemetryConfig
    {
    }
}
