﻿namespace FCG.TechChallenge.Jogos.Infrastructure.Config.Options
{
    public sealed class SqlOptions
    {
        public string ConnectionString { get; set; } = string.Empty;
    }
}
