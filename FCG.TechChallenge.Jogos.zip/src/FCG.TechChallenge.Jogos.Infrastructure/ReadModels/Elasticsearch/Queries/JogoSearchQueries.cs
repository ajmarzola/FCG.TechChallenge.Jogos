﻿namespace FCG.TechChallenge.Jogos.Infrastructure.ReadModels.Elasticsearch.Queries
{
    public class JogoSearchQueries
    {
    }
}
