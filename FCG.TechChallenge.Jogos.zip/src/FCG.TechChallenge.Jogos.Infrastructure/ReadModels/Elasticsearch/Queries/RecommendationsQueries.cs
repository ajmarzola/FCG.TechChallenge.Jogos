﻿namespace FCG.TechChallenge.Jogos.Infrastructure.ReadModels.Elasticsearch.Queries
{
    internal class RecommendationsQueries
    {
    }
}
