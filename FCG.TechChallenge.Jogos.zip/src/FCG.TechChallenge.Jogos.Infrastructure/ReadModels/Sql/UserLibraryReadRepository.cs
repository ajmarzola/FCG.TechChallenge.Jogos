﻿namespace FCG.TechChallenge.Jogos.Infrastructure.ReadModels.Sql
{
    public class UserLibraryReadRepository
    {
    }
}
