﻿namespace FCG.TechChallenge.Jogos.Api.Middleware
{
    public class ExceptionHandlingMiddleware
    {
    }
}
