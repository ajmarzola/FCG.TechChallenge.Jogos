﻿namespace FCG.TechChallenge.Jogos.Api.Endpoints.Users
{
    public class LibraryEndpoints
    {
    }
}
