﻿namespace FCG.TechChallenge.Jogos.Application.DTOs
{
    public class JogoDto
    {
    }
}
