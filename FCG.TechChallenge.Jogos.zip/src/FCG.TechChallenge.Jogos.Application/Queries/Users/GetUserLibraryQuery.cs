﻿namespace FCG.TechChallenge.Jogos.Application.Queries.Users
{
    public class GetUserLibraryQuery
    {
    }
}
