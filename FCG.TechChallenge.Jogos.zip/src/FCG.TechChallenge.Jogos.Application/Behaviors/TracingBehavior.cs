﻿namespace FCG.TechChallenge.Jogos.Application.Behaviors
{
    public class TracingBehavior
    {
    }
}
