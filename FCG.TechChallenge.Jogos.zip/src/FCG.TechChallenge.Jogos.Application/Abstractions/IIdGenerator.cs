﻿namespace FCG.TechChallenge.Jogos.Application.Abstractions
{
    public class IIdGenerator
    {
    }
}
