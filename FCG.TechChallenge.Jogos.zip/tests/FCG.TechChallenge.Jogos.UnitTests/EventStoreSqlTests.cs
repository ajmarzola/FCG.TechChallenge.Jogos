﻿namespace FCG.TechChallenge.Jogos.UnitTests
{
    public class EventStoreSqlTests
    {
    }
}
