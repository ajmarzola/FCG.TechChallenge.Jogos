﻿namespace FCG.TechChallenge.Jogos.UnitTests.Domain
{
    public class JogoTests
    {
    }
}
