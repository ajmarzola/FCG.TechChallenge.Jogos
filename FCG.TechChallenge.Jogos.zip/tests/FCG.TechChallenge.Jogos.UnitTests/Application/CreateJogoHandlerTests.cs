﻿namespace FCG.TechChallenge.Jogos.UnitTests.Application
{
    public class CreateJogoHandlerTests
    {
    }
}
