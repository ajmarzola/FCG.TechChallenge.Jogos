﻿namespace FCG.TechChallenge.Jogos.UnitTests
{
    public class ElasticsearchProjectionTests
    {
    }
}
